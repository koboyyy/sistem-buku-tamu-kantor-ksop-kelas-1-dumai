<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Kunjungan - KSOP Dumai</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f8f9fa; }
        .navbar-custom {
            background-color: white;
            box-shadow: 0 2px 4px rgba(0,0,0,.05);
        }
        .card-history {
            border: none;
            border-radius: 15px;
        }
        .table thead th {
            background-color: #f8f9fa;
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 1px;
            color: #6c757d;
            border-top: none;
            padding: 15px;
        }
        .table tbody td {
            padding: 15px;
            vertical-align: middle;
        }
        .status-badge {
            padding: 6px 12px;
            border-radius: 50px;
            font-weight: 600;
            font-size: 0.75rem;
        }
        .antrian-box {
            background-color: #e7f1ff;
            color: #0d6efd;
            padding: 4px 10px;
            border-radius: 6px;
            font-family: 'Courier New', Courier, monospace;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-custom px-4 py-3 mb-4 shadow-sm">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center fw-bold text-primary" href="{{ route('tamu.dashboard') }}">
            <i class="bi bi-arrow-left me-2"></i> Dashboard
        </a>
        <span class="navbar-text fw-bold text-dark d-none d-md-block">Riwayat Kunjungan</span>
    </div>
</nav>

<div class="container py-2">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-0">Riwayat Kunjungan Anda</h4>
            <p class="text-muted small">Daftar seluruh agenda kunjungan yang pernah Anda buat.</p>
        </div>
        <a href="{{ route('tamu.kunjungan.form') }}" class="btn btn-primary rounded-pill px-4 shadow-sm">
            <i class="bi bi-plus-lg me-1"></i> Baru
        </a>
    </div>

    @if($kunjungans->isEmpty())
        <div class="card card-history shadow-sm py-5 text-center">
            <div class="card-body">
                <i class="bi bi-calendar-x text-muted display-1 mb-3"></i>
                <h5>Belum Ada Riwayat</h5>
                <p class="text-muted small">Anda belum pernah melakukan pendaftaran kunjungan.</p>
            </div>
        </div>
    @else
        <div class="card card-history shadow-sm overflow-hidden">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th class="text-center">No. Antrian</th>
                            <th>Tanggal</th>
                            <th>Tujuan Bidang</th>
                            <th>Keperluan</th>
                            <th class="text-center">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($kunjungans as $k)
                        @php $s = $k->status_kunjungan; @endphp
                        <tr>
                            <td class="text-center">
                                <span class="antrian-box fw-bold">#{{ $k->nomor_antrian }}</span>
                            </td>
                            <td>
                                <div class="fw-bold text-dark">{{ \Carbon\Carbon::parse($k->tanggal_kunjungan)->format('d M Y') }}</div>
                                <small class="text-muted"><i class="bi bi-clock me-1"></i>{{ $k->jam_masuk }} WIB</small>
                            </td>
                            <td>
                                <div class="text-dark">{{ $k->bidang->nama_bidang ?? '-' }}</div>
                                <small class="text-muted text-uppercase" style="font-size: 0.7rem;">
                                    <i class="bi bi-arrow-return-right me-1"></i>{{ $k->subbagian->nama_subbagian ?? '-' }}
                                </small>
                            </td>
                            <td>
                                <span class="text-dark small">{{ Str::limit($k->keperluan, 45) }}</span>
                            </td>
                            <td class="text-center">
                                @if($s === 'diterima')
                                    <span class="status-badge bg-success-subtle text-success border border-success">
                                        <i class="bi bi-check2-circle me-1"></i> Diterima
                                    </span>
                                @elseif($s === 'ditolak')
                                    <span class="status-badge bg-danger-subtle text-danger border border-danger">
                                        <i class="bi bi-x-circle me-1"></i> Ditolak
                                    </span>
                                @else
                                    <span class="status-badge bg-warning-subtle text-warning border border-warning">
                                        <i class="bi bi-hourglass-split me-1"></i> Pending
                                    </span>
                                @endif
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
        <div class="mt-4 text-center">
            <p class="text-muted small">Menampilkan <strong>{{ $kunjungans->count() }}</strong> data kunjungan terakhir.</p>
        </div>
    @endif
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>