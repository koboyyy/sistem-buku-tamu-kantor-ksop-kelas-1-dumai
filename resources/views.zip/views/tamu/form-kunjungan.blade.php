<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Kunjungan - KSOP Dumai</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f8f9fa; }
        .form-card { border: none; border-radius: 15px; }
        .form-label { font-weight: 600; color: #495057; font-size: 0.9rem; }
        .input-group-text { background-color: #f8f9fa; border-right: none; }
        .form-control, .form-select { border-left: none; }
        .form-control:focus, .form-select:focus { 
            box-shadow: none; 
            border-color: #dee2e6;
        }
        .input-group:focus-within {
            box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.1);
            border-radius: 8px;
        }
        .input-group:focus-within .input-group-text,
        .input-group:focus-within .form-control,
        .input-group:focus-within .form-select {
            border-color: #0d6efd;
        }
    </style>
</head>
<body>

<!-- Top Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary px-4 py-3 mb-4 shadow-sm">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="{{ route('tamu.dashboard') }}">
            <i class="bi bi-arrow-left-circle me-2"></i>
            <span class="fw-bold">Kembali ke Dashboard</span>
        </a>
    </div>
</nav>

<div class="container py-2">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            
            <div class="mb-4">
                <h4 class="fw-bold">Pendaftaran Kunjungan</h4>
                <p class="text-muted small">Silahkan lengkapi detail kunjungan Anda di bawah ini.</p>
            </div>

            @if ($errors->any())
                <div class="alert alert-danger border-0 shadow-sm mb-4">
                    <div class="fw-bold mb-1"><i class="bi bi-exclamation-octagon me-2"></i>Terjadi Kesalahan:</div>
                    <ul class="mb-0 small">
                        @foreach($errors->all() as $err)
                            <li>{{ $err }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="card form-card shadow-sm mb-5">
                <div class="card-body p-4 p-md-5">
                    <form action="{{ route('tamu.kunjungan.simpan') }}" method="POST">
                        @csrf

                        <!-- Section: Tujuan -->
                        <div class="mb-4">
                            <h6 class="text-primary fw-bold mb-3"><i class="bi bi-geo-alt me-2"></i>Destinasi Kunjungan</h6>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Bidang yang Dituju <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="bi bi-building"></i></span>
                                        <select name="id_bidang" id="id_bidang" class="form-select" required>
                                            <option value="">-- Pilih Bidang --</option>
                                            @foreach($bidangs as $b)
                                                <option value="{{ $b->id_bidang }}" {{ old('id_bidang') == $b->id_bidang ? 'selected' : '' }}>
                                                    {{ $b->nama_bidang }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Subbagian <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="bi bi-diagram-3"></i></span>
                                        <select name="id_subbagian" id="id_subbagian" class="form-select" required>
                                            <option value="">-- Pilih Subbagian --</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr class="my-4 opacity-25">

                        <!-- Section: Waktu -->
                        <div class="mb-4">
                            <h6 class="text-primary fw-bold mb-3"><i class="bi bi-clock-history me-2"></i>Waktu Kedatangan</h6>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Tanggal Kunjungan <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="bi bi-calendar-event"></i></span>
                                        <input type="date" name="tanggal_kunjungan" class="form-control"
                                            min="{{ date('Y-m-d') }}" value="{{ old('tanggal_kunjungan') }}" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Jam Masuk (Estimasi) <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="bi bi-alarm"></i></span>
                                        <input type="time" name="jam_masuk" class="form-control" value="{{ old('jam_masuk') }}" required>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr class="my-4 opacity-25">

                        <!-- Section: Keperluan -->
                        <div class="mb-4">
                            <h6 class="text-primary fw-bold mb-3"><i class="bi bi-chat-left-dots me-2"></i>Detail Keperluan</h6>
                            <div class="mb-3">
                                <label class="form-label">Keperluan Utama <span class="text-danger">*</span></label>
                                <textarea name="keperluan" class="form-control border-start" rows="3" placeholder="Contoh: Koordinasi terkait izin pelabuhan..." required style="border-left: 1px solid #dee2e6;">{{ old('keperluan') }}</textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Keterangan Tambahan (Opsional)</label>
                                <textarea name="keterangan" class="form-control border-start" rows="2" placeholder="Informasi tambahan lainnya..." style="border-left: 1px solid #dee2e6;">{{ old('keterangan') }}</textarea>
                            </div>
                        </div>

                        <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-5">
                            <a href="{{ route('tamu.dashboard') }}" class="btn btn-light border px-4 py-2 me-md-2">Batal</a>
                            <button type="submit" class="btn btn-primary px-5 py-2 fw-bold shadow-sm">
                                <i class="bi bi-send me-2"></i>Daftar Kunjungan
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Data subbagian per bidang
const subbagianData = @json($bidangs->mapWithKeys(fn($b) => [
    $b->id_bidang => $b->subbagians->map(fn($s) => ['id' => $s->id_subbagian, 'nama' => $s->nama_subbagian])
]));

document.getElementById('id_bidang').addEventListener('change', function () {
    const bidangId = this.value;
    const subSelect = document.getElementById('id_subbagian');
    subSelect.innerHTML = '<option value="">-- Pilih Subbagian --</option>';

    if (bidangId && subbagianData[bidangId]) {
        subbagianData[bidangId].forEach(s => {
            subSelect.innerHTML += `<option value="${s.id}">${s.nama}</option>`;
        });
    }
});
</script>

</body>
</html>