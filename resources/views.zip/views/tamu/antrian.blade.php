<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nomor Antrian - KSOP Dumai</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f4f7f6; }
        .ticket-card {
            border: none;
            border-radius: 20px;
            overflow: hidden;
        }
        .ticket-header {
            background: linear-gradient(135deg, #198754 0%, #146c43 100%);
            padding: 30px;
            color: white;
        }
        .queue-number {
            background-color: #f8f9fa;
            border: 2px dashed #0d6efd;
            color: #0d6efd;
            font-size: 3.5rem;
            letter-spacing: 2px;
        }
        .info-table th { color: #6c757d; font-weight: 500; font-size: 0.85rem; text-transform: uppercase; }
        .info-table td { font-weight: 600; color: #343a40; }
        .btn-riwayat { border-radius: 10px; padding: 12px; transition: all 0.3s; }
    </style>
</head>
<body>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            
            <div class="text-center mb-4">
                <a href="{{ route('tamu.dashboard') }}" class="text-decoration-none text-muted">
                    <i class="bi bi-arrow-left me-1"></i> Kembali ke Dashboard
                </a>
            </div>

            <div class="card ticket-card shadow-lg">
                <div class="ticket-header text-center">
                    <div class="bg-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                        <i class="bi bi-check-lg text-success fs-2"></i>
                    </div>
                    <h4 class="fw-bold mb-0">Pendaftaran Berhasil</h4>
                    <p class="small opacity-75 mb-0">Silahkan tunjukkan tiket ini kepada petugas</p>
                </div>

                <div class="card-body p-4 text-center">
                    <p class="text-muted small mb-2">NOMOR ANTRIAN ANDA</p>
                    <div class="queue-number rounded-3 py-3 px-4 mb-4 fw-bold d-inline-block">
                        {{ $kunjungan->nomor_antrian }}
                    </div>

                    <div class="bg-light rounded-3 p-3 mb-4">
                        <table class="table table-borderless info-table text-start mb-0">
                            <tr>
                                <th><i class="bi bi-calendar3 me-2"></i>Tanggal</th>
                                <td>{{ \Carbon\Carbon::parse($kunjungan->tanggal_kunjungan)->format('d M Y') }}</td>
                            </tr>
                            <tr>
                                <th><i class="bi bi-clock me-2"></i>Estimasi</th>
                                <td>{{ $kunjungan->jam_masuk }} WIB</td>
                            </tr>
                            <tr>
                                <th><i class="bi bi-building me-2"></i>Tujuan</th>
                                <td>
                                    <div class="d-flex flex-column">
                                        <span>{{ $kunjungan->bidang->nama_bidang }}</span>
                                        <small class="text-muted fw-normal">{{ $kunjungan->subbagian->nama_subbagian }}</small>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th><i class="bi bi-info-circle me-2"></i>Status</th>
                                <td><span class="badge bg-warning-subtle text-warning border border-warning px-3">Pending</span></td>
                            </tr>
                        </table>
                    </div>

                    <div class="d-grid gap-2">
                        <button onclick="window.print()" class="btn btn-dark btn-riwayat">
                            <i class="bi bi-printer me-2"></i> Cetak Tiket
                        </button>
                        <a href="{{ route('tamu.riwayat') }}" class="btn btn-outline-primary btn-riwayat">
                            Lihat Riwayat Kunjungan
                        </a>
                    </div>
                </div>
                
                <div class="card-footer bg-white border-0 text-center pb-4">
                    <small class="text-muted" style="font-size: 0.7rem;">
                        <i class="bi bi-shield-lock me-1"></i> Sistem Buku Tamu Digital KSOP Kelas I Dumai
                    </small>
                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>