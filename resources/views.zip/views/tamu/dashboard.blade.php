<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Tamu - KSOP Dumai</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f8f9fa; }
        .welcome-banner {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
            border-radius: 15px;
            color: white;
            padding: 30px;
        }
        .action-card {
            border: none;
            border-radius: 12px;
            transition: transform 0.2s;
        }
        .action-card:hover {
            transform: translateY(-5px);
        }
        .status-card {
            border-left: 5px solid;
            border-radius: 10px;
        }
        .navbar-custom {
            background-color: white;
            box-shadow: 0 2px 4px rgba(0,0,0,.05);
        }
    </style>
</head>
<body>

<!-- Top Navigation -->
<nav class="navbar navbar-expand-lg navbar-custom px-4 py-3 mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold text-primary" href="#">
            <i class="bi bi-door-open-fill me-2"></i>E-Tamu KSOP
        </a>
        <div class="d-flex align-items-center gap-3">
            <span class="d-none d-md-inline text-muted small">Halo, <strong>{{ $tamu->nama }}</strong></span>
            <form action="{{ route('logout') }}" method="POST" class="m-0">
                @csrf
                <button class="btn btn-outline-danger btn-sm rounded-pill px-3">
                    <i class="bi bi-box-arrow-right me-1"></i> Logout
                </button>
            </form>
        </div>
    </div>
</nav>

<div class="container py-2">

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm mb-4" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i> {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <!-- Welcome Section -->
    <div class="welcome-banner shadow-sm mb-4">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h3 class="fw-bold">Selamat Datang, {{ explode(' ', $tamu->nama)[0] }}!</h3>
                <p class="mb-0 opacity-75">Gunakan layanan mandiri untuk pendaftaran kunjungan ke Kantor KSOP Kelas I Dumai secara cepat dan efisien.</p>
            </div>
            <div class="col-md-4 text-end d-none d-md-block">
                <i class="bi bi-clipboard2-check" style="font-size: 4rem; opacity: 0.3;"></i>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="row g-4 mb-5">
        <div class="col-md-6">
            <div class="card action-card shadow-sm h-100">
                <div class="card-body p-4">
                    <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 50px; height: 50px;">
                        <i class="bi bi-plus-lg fs-4"></i>
                    </div>
                    <h5 class="fw-bold">Buat Kunjungan</h5>
                    <p class="text-muted small">Daftarkan agenda kunjungan Anda untuk mendapatkan nomor antrian digital.</p>
                    <a href="{{ route('tamu.kunjungan.form') }}" class="btn btn-primary w-100 rounded-pill">
                        Daftar Sekarang
                    </a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card action-card shadow-sm h-100">
                <div class="card-body p-4">
                    <div class="bg-secondary bg-opacity-10 text-secondary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 50px; height: 50px;">
                        <i class="bi bi-clock-history fs-4"></i>
                    </div>
                    <h5 class="fw-bold">Riwayat & Status</h5>
                    <p class="text-muted small">Pantau status persetujuan kunjungan dan lihat riwayat kedatangan sebelumnya.</p>
                    <a href="{{ route('tamu.riwayat') }}" class="btn btn-outline-secondary w-100 rounded-pill">
                        Lihat Riwayat
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Latest Activity -->
    @if($kunjunganTerakhir)
    <div class="row">
        <div class="col-12">
            <h6 class="fw-bold mb-3"><i class="bi bi-info-circle me-2"></i>Kunjungan Terakhir Anda</h6>
            @php $s = $kunjunganTerakhir->status_kunjungan; @endphp
            <div class="card status-card shadow-sm border-{{ $s === 'diterima' ? 'success' : ($s === 'ditolak' ? 'danger' : 'warning') }}">
                <div class="card-body p-4">
                    <div class="row align-items-center">
                        <div class="col-md-3 border-end">
                            <small class="text-muted d-block text-uppercase">No. Antrian</small>
                            <h4 class="fw-bold text-primary mb-0">#{{ $kunjunganTerakhir->nomor_antrian }}</h4>
                        </div>
                        <div class="col-md-4 px-md-4 py-3 py-md-0">
                            <small class="text-muted d-block text-uppercase">Keperluan</small>
                            <p class="mb-0 text-dark fw-medium">{{ $kunjunganTerakhir->keperluan }}</p>
                            <small class="text-muted"><i class="bi bi-calendar-event me-1"></i>{{ \Carbon\Carbon::parse($kunjunganTerakhir->tanggal_kunjungan)->format('d M Y') }}</small>
                        </div>
                        <div class="col-md-3 py-2 py-md-0">
                            <small class="text-muted d-block text-uppercase mb-1">Status</small>
                            <span class="badge rounded-pill px-3 py-2 bg-{{ $s === 'diterima' ? 'success' : ($s === 'ditolak' ? 'danger' : 'warning') }}-subtle text-{{ $s === 'diterima' ? 'success' : ($s === 'ditolak' ? 'danger' : 'warning') }} border border-{{ $s === 'diterima' ? 'success' : ($s === 'ditolak' ? 'danger' : 'warning') }}">
                                <i class="bi {{ $s === 'diterima' ? 'bi-check-circle' : ($s === 'ditolak' ? 'bi-x-circle' : 'bi-hourglass-split') }} me-1"></i>
                                {{ ucfirst($s) }}
                            </span>
                        </div>
                        <div class="col-md-2 text-md-end">
                            <a href="{{ route('tamu.riwayat') }}" class="btn btn-sm btn-light border rounded">Detail</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endif

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>