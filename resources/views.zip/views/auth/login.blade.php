<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Buku Tamu KSOP Dumai</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    @vite('resources/css/app.css')

    <style>
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
        }
        .card-login {
            border: none;
            border-radius: 15px;
            overflow: hidden;
        }
        .login-header {
            background-color: #dc3545; /* Merah KSOP */
            padding: 30px;
            color: white;
            text-align: center;
        }
        .nav-tabs {
            border-bottom: 2px solid #f1f1f1;
        }
        .nav-link {
            color: #6c757d;
            font-weight: 600;
            border: none !important;
            padding: 12px 20px;
        }
        .nav-link.active {
            color: #dc3545 !important;
            border-bottom: 3px solid #dc3545 !important;
            background: transparent !important;
        }
        .form-control {
            border-radius: 8px;
            padding: 12px;
            border: 1px solid #dee2e6;
        }
        .form-control:focus {
            border-color: #dc3545;
            box-shadow: 0 0 0 0.25rem rgba(220, 53, 69, 0.1);
        }
        .btn-login {
            padding: 12px;
            font-weight: 600;
            border-radius: 8px;
            transition: all 0.3s;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5 col-lg-4">
            
            <div class="text-center mb-4">
                <!-- Anda bisa meletakkan logo KSOP di sini jika ada -->
                <h4 class="fw-bold text-dark text-uppercase">Buku Tamu</h4>
                <p class="text-muted small">KSOP Kelas I Dumai</p>
            </div>

            <div class="card card-login shadow-lg">
                <div class="card-body p-0">
                    
                    {{-- Tab Navigation --}}
                    <ul class="nav nav-tabs nav-fill" id="loginTab">
                        <li class="nav-item">
                            <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tabTamu">
                                <i class="bi bi-person me-2"></i>Tamu
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tabAdmin">
                                <i class="bi bi-shield-lock me-2"></i>Admin
                            </button>
                        </li>
                    </ul>

                    <div class="p-4">
                        @if ($errors->any())
                            <div class="alert alert-danger d-flex align-items-center mb-4" role="alert">
                                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                                <div>{{ $errors->first() }}</div>
                            </div>
                        @endif

                        <div class="tab-content">
                            {{-- Login Tamu --}}
                            <div class="tab-pane fade show active" id="tabTamu">
                                <form action="{{ route('login.tamu') }}" method="POST">
                                    @csrf
                                    <div class="mb-3">
                                        <label class="form-label small fw-bold">Alamat Email</label>
                                        <div class="input-group">
                                            <span class="input-group-text bg-light"><i class="bi bi-envelope"></i></span>
                                            <input type="email" name="email" class="form-control" placeholder="nama@email.com" required value="{{ old('email') }}">
                                        </div>
                                    </div>
                                    <div class="mb-4">
                                        <label class="form-label small fw-bold">Password</label>
                                        <div class="input-group">
                                            <span class="input-group-text bg-light"><i class="bi bi-lock"></i></span>
                                            <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary btn-login w-100 mb-3 shadow-sm">
                                        Masuk sebagai Tamu
                                    </button>
                                </form>
                                <div class="text-center">
                                    <p class="small text-muted mb-0">Belum memiliki akun? <a href="{{ route('register') }}" class="text-primary text-decoration-none fw-bold">Daftar Sekarang</a></p>
                                </div>
                            </div>

                            {{-- Login Admin --}}
                            <div class="tab-pane fade" id="tabAdmin">
                                <form action="{{ route('login.admin') }}" method="POST">
                                    @csrf
                                    <div class="mb-3">
                                        <label class="form-label small fw-bold">Username Admin</label>
                                        <div class="input-group">
                                            <span class="input-group-text bg-light"><i class="bi bi-person-badge"></i></span>
                                            <input type="text" name="username" class="form-control" placeholder="Masukkan username" required>
                                        </div>
                                    </div>
                                    <div class="mb-4">
                                        <label class="form-label small fw-bold">Password</label>
                                        <div class="input-group">
                                            <span class="input-group-text bg-light"><i class="bi bi-key"></i></span>
                                            <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-danger btn-login w-100 shadow-sm">
                                        Otorisasi Admin
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="text-center mt-4">
                <small class="text-muted">&copy; {{ date('Y') }} KSOP Kelas I Dumai. All Rights Reserved.</small>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>