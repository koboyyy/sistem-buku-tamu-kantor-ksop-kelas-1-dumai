<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Kunjungan - Admin KSOP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <style>
        body { overflow-x: hidden; background-color: #f8f9fa; }
        
        /* Sidebar Styling */
        #sidebar {
            min-width: 250px; max-width: 250px;
            min-height: 100vh; background-color: #dc3545;
            transition: all 0.3s; position: fixed;
        }
        #sidebar .sidebar-header { padding: 20px; background: #b02a37; }
        #sidebar ul.components { padding: 20px 0; }
        #sidebar ul li a { padding: 10px 20px; display: block; color: white; text-decoration: none; }
        #sidebar ul li a:hover { background: #b02a37; }
        #sidebar ul li.active > a { background: #a02632; font-weight: bold; }
        
        /* Content Styling */
        #content { width: calc(100% - 250px); margin-left: 250px; min-height: 100vh; }
        .navbar-custom { background-color: white; box-shadow: 0 2px 4px rgba(0,0,0,.08); }

        /* Print Logic */
        @media print {
            .no-print { display: none !important; }
            #content { width: 100% !important; margin-left: 0 !important; padding: 0 !important; }
            body { background-color: white; font-size: 12px; }
            .card { border: none !important; box-shadow: none !important; }
            .table-responsive { overflow: visible !important; }
        }
    </style>
</head>
<body>

<div class="d-flex">
    <!-- Sidebar (Hidden on Print) -->
    <nav id="sidebar" class="no-print">
        <div class="sidebar-header text-center">
            <h4 class="text-white mb-0 fw-bold">KSOP DUMAI</h4>
        </div>
        <ul class="list-unstyled components">
            <li><a href="{{ route('admin.dashboard') }}"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a></li>
            <li><a href="{{ route('admin.tamu.index') }}"><i class="bi bi-people-fill me-2"></i> Data Tamu</a></li>
            <li><a href="{{ route('admin.kunjungan.index') }}"><i class="bi bi-calendar-check me-2"></i> Data Kunjungan</a></li>
            <li class="active"><a href="#"><i class="bi bi-journal-text me-2"></i> Laporan</a></li>
            <hr class="text-white opacity-25 mx-3">
            <li><a href="#"><i class="bi bi-box-arrow-right me-2"></i> Logout</a></li>
        </ul>
    </nav>

    <!-- Page Content -->
    <div id="content">
        <!-- Top Navbar (Hidden on Print) -->
        <nav class="navbar navbar-expand-lg navbar-custom px-4 py-3 no-print">
            <div class="container-fluid">
                <span class="navbar-brand mb-0 h1">Laporan Kunjungan</span>
                <button type="button" onclick="window.print()" class="btn btn-outline-danger shadow-sm">
                    <i class="bi bi-printer me-2"></i> Cetak Laporan
                </button>
            </div>
        </nav>

        <div class="container-fluid p-4">
            
            <!-- Filter Card (Hidden on Print) -->
            <div class="card shadow-sm mb-4 no-print border-0">
                <div class="card-body">
                    <form method="GET" class="row g-3 align-items-end">
                        <div class="col-md-3">
                            <label class="form-label small fw-bold">Dari Tanggal</label>
                            <input type="date" name="dari" class="form-control" value="{{ request('dari') }}">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-bold">Sampai Tanggal</label>
                            <input type="date" name="sampai" class="form-control" value="{{ request('sampai') }}">
                        </div>
                        <div class="col-md-3">
                            <button class="btn btn-danger px-4 w-100">Tampilkan Data</button>
                        </div>
                        <div class="col-md-3 text-end">
                            <a href="{{ route('admin.laporan') }}" class="btn btn-light border w-100">Reset</a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Report Sheet -->
            <div class="card shadow-sm border-0">
                <div class="card-body p-5">
                    <!-- Header Laporan (Kop Surat Style) -->
                    <div class="text-center mb-5">
                        <h5 class="fw-bold mb-1 text-uppercase">Laporan Kunjungan Tamu</h5>
                        <h6 class="mb-1">Kantor Kesyahbandaran dan Otoritas Pelabuhan Kelas I Dumai</h6>
                        <hr style="border-top: 2px solid #000; width: 100px; margin: 10px auto;">
                        @if(request('dari') && request('sampai'))
                            <p class="text-muted mb-0">Periode: {{ \Carbon\Carbon::parse(request('dari'))->format('d/m/Y') }} s/d {{ \Carbon\Carbon::parse(request('sampai'))->format('d/m/Y') }}</p>
                        @endif
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-light">
                                <tr class="text-center">
                                    <th style="width: 50px;">No</th>
                                    <th>Antrian</th>
                                    <th>Nama Tamu</th>
                                    <th>Instansi</th>
                                    <th>Tanggal</th>
                                    <th>Bidang</th>
                                    <th>Keperluan</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($kunjungans as $i => $k)
                                <tr>
                                    <td class="text-center">{{ $i + 1 }}</td>
                                    <td class="text-center fw-bold text-danger">#{{ $k->nomor_antrian }}</td>
                                    <td>{{ $k->tamu->nama ?? '-' }}</td>
                                    <td>{{ $k->tamu->instansi ?? '-' }}</td>
                                    <td class="text-nowrap">{{ \Carbon\Carbon::parse($k->tanggal_kunjungan)->format('d/m/Y') }}</td>
                                    <td><small>{{ $k->bidang->nama_bidang ?? '-' }}</small></td>
                                    <td>{{ Str::limit($k->keperluan, 30) }}</td>
                                    <td class="text-center">
                                        <span class="text-uppercase small fw-bold">{{ $k->status_kunjungan }}</span>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="8" class="text-center py-4 text-muted">Data tidak ditemukan untuk periode ini.</td>
                                </tr>
                                @endforelse
                            </tbody>
                            <tfoot class="table-light fw-bold">
                                <tr>
                                    <td colspan="7" class="text-end py-3">TOTAL KUNJUNGAN:</td>
                                    <td class="text-center py-3">{{ $kunjungans->count() }}</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                    <!-- Signature Area (Visible on Print) -->
                    <div class="row mt-5 d-none d-print-flex">
                        <div class="col-8"></div>
                        <div class="col-4 text-center">
                            <p class="mb-5">Dumai, {{ now()->translatedFormat('d F Y') }}</p>
                            <p class="mb-0 fw-bold"><u>Admin KSOP</u></p>
                            <p>NIP. ...........................</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>