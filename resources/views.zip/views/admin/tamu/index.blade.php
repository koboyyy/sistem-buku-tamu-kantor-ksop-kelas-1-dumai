<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Tamu - Admin KSOP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Tambahkan Bootstrap Icons untuk estetika -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <style>
        body {
            overflow-x: hidden;
            background-color: #f8f9fa;
        }
        #sidebar {
            min-width: 250px;
            max-width: 250px;
            min-height: 100vh;
            background-color: #dc3545; /* Warna Merah KSOP */
            transition: all 0.3s;
            position: fixed;
        }
        #sidebar .sidebar-header {
            padding: 20px;
            background: #b02a37;
        }
        #sidebar ul.components {
            padding: 20px 0;
        }
        #sidebar ul li a {
            padding: 10px 20px;
            display: block;
            color: white;
            text-decoration: none;
        }
        #sidebar ul li a:hover {
            background: #b02a37;
        }
        #sidebar ul li.active > a {
            background: #a02632;
            font-weight: bold;
        }
        #content {
            width: calc(100% - 250px);
            margin-left: 250px;
            min-height: 100vh;
            transition: all 0.3s;
        }
        .navbar-custom {
            background-color: white;
            box-shadow: 0 2px 4px rgba(0,0,0,.08);
        }
        @media (max-width: 768px) {
            #sidebar { margin-left: -250px; }
            #content { width: 100%; margin-left: 0; }
            #sidebar.active { margin-left: 0; }
        }
    </style>
</head>
<body>

<div class="d-flex">
    <!-- Sidebar -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <h4 class="text-white mb-0">Admin KSOP</h4>
        </div>

        <ul class="list-unstyled components">
            <li>
                <a href="{{ route('admin.dashboard') }}"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
            </li>
            <li class="active">
                <a href="#"><i class="bi bi-people-fill me-2"></i> Data Tamu</a>
            </li>
            <li>
                <a href="#"><i class="bi bi-journal-text me-2"></i> Laporan</a>
            </li>
            <hr class="text-white">
            <li>
                <a href="#"><i class="bi bi-box-arrow-right me-2"></i> Keluar</a>
            </li>
        </ul>
    </nav>

    <!-- Page Content -->
    <div id="content">
        <!-- Top Navbar -->
        <nav class="navbar navbar-expand-lg navbar-custom px-4 py-3">
            <div class="container-fluid">
                <span class="navbar-brand mb-0 h1 text-dark">Data Tamu</span>
                <div class="d-flex align-items-center">
                    <span class="me-3 d-none d-md-inline text-muted">Selamat Datang, Admin</span>
                    <div class="bg-danger rounded-circle" style="width: 35px; height: 35px;"></div>
                </div>
            </div>
        </nav>

        <div class="container-fluid p-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3">
                    <h5 class="card-title mb-0 text-danger">Daftar Tamu Terdaftar</h5>
                </div>
                <div class="card-body">
                    
                    @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            {{ session('success') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    @endif

                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th class="py-3">#</th>
                                    <th class="py-3">Nama</th>
                                    <th class="py-3">Instansi</th>
                                    <th class="py-3">Email</th>
                                    <th class="py-3">No. HP</th>
                                    <th class="py-3">Jml Kunjungan</th>
                                    <th class="py-3 text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($tamus as $i => $t)
                                <tr>
                                    <td>{{ $i + 1 }}</td>
                                    <td class="fw-bold">{{ $t->nama }}</td>
                                    <td>{{ $t->instansi }}</td>
                                    <td>{{ $t->email }}</td>
                                    <td>{{ $t->no_hp }}</td>
                                    <td class="text-center"><span class="badge bg-info text-dark">{{ $t->kunjungans_count }}</span></td>
                                    <td class="text-center">
                                        <form action="{{ route('admin.tamu.hapus', $t->id_tamu) }}" method="POST"
                                            onsubmit="return confirm('Hapus tamu ini?')">
                                            @csrf @method('DELETE')
                                            <button class="btn btn-outline-danger btn-sm">
                                                <i class="bi bi-trash"></i> Hapus
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="7" class="text-center py-5 text-muted">
                                        <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                                        Belum ada data tamu.
                                    </td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>