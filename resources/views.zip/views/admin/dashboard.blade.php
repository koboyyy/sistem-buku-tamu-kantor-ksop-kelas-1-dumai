<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - KSOP Dumai</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">

    @vite('resources/css/app.css')
    
    <style>
        body { overflow-x: hidden; background-color: #f8f9fa; }
        #sidebar {
            min-width: 250px; max-width: 250px;
            min-height: 100vh; background-color: #dc3545;
            transition: all 0.3s; position: fixed;
        }
        #sidebar .sidebar-header { padding: 20px; background: #b02a37; }
        #sidebar ul.components { padding: 20px 0; }
        #sidebar ul li a { padding: 10px 20px; display: block; color: white; text-decoration: none; }
        #sidebar ul li a:hover { background: #b02a37; }
        #sidebar ul li.active > a { background: #a02632; font-weight: bold; }
        #content { width: calc(100% - 250px); margin-left: 250px; min-height: 100vh; }
        .navbar-custom { background-color: white; box-shadow: 0 2px 4px rgba(0,0,0,.08); }
        
        /* Dashboard Card Styling */
        .stat-card {
            border: none;
            border-radius: 15px;
            transition: transform 0.3s ease;
        }
        .stat-card:hover { transform: translateY(-5px); }
        .icon-box {
            width: 48px;
            height: 48px;
            background: rgba(255,255,255,0.2);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }
        @media (max-width: 768px) {
            #sidebar { margin-left: -250px; }
            #content { width: 100%; margin-left: 0; }
        }
    </style>
</head>
<body>

<div class="d-flex">
    <!-- Sidebar -->
    <nav id="sidebar">
        <div class="sidebar-header flex">
            <div>
                <img src="{{ asset('logo-ksop-kelas-1-dumai.png') }}" alt="Logo KSOP Dumai" style="height:55px; display:block; margin:auto;">
            </div>
            <div>
                <h4 class="text-white mb-0 fw-bold">KSOP DUMAI</h4>
                <small class="text-white-50">Sistem Buku Tamu</small>
            </div>
        </div>
        <ul class="list-unstyled components">
            <li class="active"><a href="#"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a></li>
            <li><a href="{{ route('admin.tamu.index') }}"><i class="bi bi-people-fill me-2"></i> Data Tamu</a></li>
            <li><a href="{{ route('admin.kunjungan.index') }}"><i class="bi bi-calendar-check me-2"></i> Data Kunjungan</a></li>
            <li><a href="{{ route('admin.laporan') }}"><i class="bi bi-journal-text me-2"></i> Laporan</a></li>
            <hr class="text-white opacity-25 mx-3">
            <li>
                <form action="{{ route('logout') }}" method="POST" id="logout-form" class="d-none">@csrf</form>
                <a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="bi bi-box-arrow-right me-2"></i> Logout
                </a>
            </li>
        </ul>
    </nav>

    <!-- Page Content -->
    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-custom px-4 py-3">
            <div class="container-fluid">
                <span class="navbar-brand mb-0 h1">Dashboard Overview</span>
                <div class="text-muted small">
                    <i class="bi bi-clock-history me-1"></i> {{ now()->format('d M Y, H:i') }}
                </div>
            </div>
        </nav>

        <div class="container-fluid p-4">
            <div class="mb-4">
                <h4 class="fw-bold">Selamat Datang, Admin!</h4>
                <p class="text-muted">Berikut adalah ringkasan data statistik buku tamu Anda hari ini.</p>
            </div>

            <!-- Stats Cards -->
            <div class="row g-4">
                <div class="col-md-3">
                    <div class="card stat-card bg-primary text-white p-2">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="fw-bold mb-0">{{ $totalTamu }}</h3>
                                    <small class="opacity-75">Total Tamu</small>
                                </div>
                                <div class="icon-box"><i class="bi bi-people"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card bg-dark text-white p-2">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="fw-bold mb-0">{{ $totalKunjungan }}</h3>
                                    <small class="opacity-75">Total Kunjungan</small>
                                </div>
                                <div class="icon-box"><i class="bi bi-card-checklist"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card bg-warning text-dark p-2">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="fw-bold mb-0">{{ $pending }}</h3>
                                    <small class="text-dark opacity-75">Menunggu (Pending)</small>
                                </div>
                                <div class="icon-box bg-dark bg-opacity-10"><i class="bi bi-hourglass-split"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card stat-card bg-success text-white p-2">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="fw-bold mb-0">{{ $diterima }}</h3>
                                    <small class="opacity-75">Diterima</small>
                                </div>
                                <div class="icon-box"><i class="bi bi-check-circle"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Call to Action Area -->
            <div class="row mt-5">
                <div class="col-lg-12">
                    <div class="card border-0 shadow-sm p-4 text-center">
                        <div class="py-4">
                            <i class="bi bi-bell-fill text-warning display-4 mb-3 d-block"></i>
                            <h5 class="fw-bold">Ada {{ $pending }} Kunjungan Perlu Tindakan</h5>
                            <p class="text-muted">Tinjau permohonan kunjungan yang baru masuk dan berikan status persetujuan.</p>
                            <a href="{{ route('admin.kunjungan.index', ['status' => 'pending']) }}" class="btn btn-danger px-4 py-2 rounded-pill">
                                Lihat Semua Kunjungan Pending <i class="bi bi-arrow-right ms-2"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>