<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Kunjungan - Admin KSOP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    @vite('resources/css/app.css')
    
    <style>
        body { overflow-x: hidden; background-color: #f8f9fa; }
        #sidebar {
            min-width: 250px; max-width: 250px;
            min-height: 100vh; background-color: #dc3545;
            transition: all 0.3s; position: fixed;
        }
        #sidebar .sidebar-header { padding: 20px; background: #b02a37; }
        #sidebar ul.components { padding: 20px 0; }
        #sidebar ul li a { padding: 10px 20px; display: block; color: white; text-decoration: none; }
        #sidebar ul li a:hover { background: #b02a37; }
        #sidebar ul li.active > a { background: #a02632; font-weight: bold; }
        #content { width: calc(100% - 250px); margin-left: 250px; min-height: 100vh; }
        .navbar-custom { background-color: white; box-shadow: 0 2px 4px rgba(0,0,0,.08); }
        .card { border: none; border-radius: 12px; box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075); }
        .info-label { color: #6c757d; font-weight: 500; width: 35%; }
        @media (max-width: 768px) {
            #sidebar { margin-left: -250px; }
            #content { width: 100%; margin-left: 0; }
        }
    </style>
</head>
<body>

<div class="d-flex">
    <!-- Sidebar -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <h4 class="text-white mb-0">Admin KSOP</h4>
        </div>
        <ul class="list-unstyled components">
            <li><a href="{{ route('admin.dashboard') }}"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a></li>
            <li><a href="{{ route('admin.tamu.index') }}"><i class="bi bi-people-fill me-2"></i> Data Tamu</a></li>
            <li class="active"><a href="{{ route('admin.kunjungan.index') }}"><i class="bi bi-calendar-check me-2"></i> Data Kunjungan</a></li>
            <li><a href="#"><i class="bi bi-journal-text me-2"></i> Laporan</a></li>
            <hr class="text-white">
            <li><a href="#"><i class="bi bi-box-arrow-right me-2"></i> Keluar</a></li>
        </ul>
    </nav>

    <!-- Page Content -->
    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-custom px-4 py-3">
            <div class="container-fluid">
                <div class="d-flex align-items-center">
                    <a href="{{ route('admin.kunjungan.index') }}" class="btn btn-outline-danger btn-sm me-3">
                        <i class="bi bi-arrow-left"></i> Kembali
                    </a>
                    <span class="navbar-brand mb-0 h1">Detail Kunjungan</span>
                </div>
            </div>
        </nav>

        <div class="container-fluid p-4">
            
            @if(session('success'))
                <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm mb-4">
                    <i class="bi bi-check-circle-fill me-2"></i> {{ session('success') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif

            <div class="row g-4">
                <!-- Info Kunjungan Utama -->
                <div class="col-lg-8">
                    <div class="card mb-4">
                        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                            <h5 class="mb-0 fw-bold">Informasi Kunjungan</h5>
                            <span class="badge bg-danger">#{{ $kunjungan->nomor_antrian }}</span>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <div class="col-sm-6">
                                    <p class="mb-1 info-label text-uppercase small">Nama Tamu</p>
                                    <p class="fw-bold mb-0 text-dark">{{ $kunjungan->tamu->nama ?? '-' }}</p>
                                </div>
                                <div class="col-sm-6">
                                    <p class="mb-1 info-label text-uppercase small">Instansi</p>
                                    <p class="fw-bold mb-0 text-dark">{{ $kunjungan->tamu->instansi ?? '-' }}</p>
                                </div>
                            </div>
                            <hr class="opacity-50">
                            <div class="row mb-3">
                                <div class="col-sm-4">
                                    <p class="mb-1 info-label text-uppercase small">Tanggal</p>
                                    <p class="mb-0"><i class="bi bi-calendar3 me-1"></i> {{ \Carbon\Carbon::parse($kunjungan->tanggal_kunjungan)->format('d/m/Y') }}</p>
                                </div>
                                <div class="col-sm-4">
                                    <p class="mb-1 info-label text-uppercase small">Jam Masuk</p>
                                    <p class="mb-0"><i class="bi bi-clock me-1"></i> {{ $kunjungan->jam_masuk }} WIB</p>
                                </div>
                                <div class="col-sm-4">
                                    <p class="mb-1 info-label text-uppercase small">No. HP</p>
                                    <p class="mb-0"><i class="bi bi-whatsapp me-1"></i> {{ $kunjungan->tamu->no_hp ?? '-' }}</p>
                                </div>
                            </div>
                            <hr class="opacity-50">
                            <div class="mb-3">
                                <p class="mb-1 info-label text-uppercase small">Tujuan Bidang / Subbagian</p>
                                <p class="mb-0 fw-bold text-danger">
                                    {{ $kunjungan->bidang->nama_bidang ?? '-' }} 
                                    <span class="text-muted fw-normal">/ {{ $kunjungan->subbagian->nama_subbagian ?? '-' }}</span>
                                </p>
                            </div>
                            <div class="mb-3">
                                <p class="mb-1 info-label text-uppercase small">Keperluan</p>
                                <p class="mb-0 p-3 bg-light rounded border">{{ $kunjungan->keperluan }}</p>
                            </div>
                        </div>
                    </div>

                    <!-- Riwayat Status -->
                    <div class="card">
                        <div class="card-header bg-white py-3">
                            <h5 class="mb-0 fw-bold">Riwayat Perubahan Status</h5>
                        </div>
                        <div class="card-body p-0">
                            <ul class="list-group list-group-flush">
                                @forelse($kunjungan->logStatuses as $log)
                                <li class="list-group-item d-flex justify-content-between align-items-center py-3">
                                    <div>
                                        @php $ls = $log->status; @endphp
                                        <span class="badge rounded-pill bg-{{ $ls === 'diterima' ? 'success' : ($ls === 'ditolak' ? 'danger' : 'warning') }} me-2">
                                            {{ ucfirst($ls) }}
                                        </span>
                                        <span class="small">Oleh: <strong>{{ $log->admin->nama_admin ?? 'Admin' }}</strong></span>
                                    </div>
                                    <small class="text-muted">{{ \Carbon\Carbon::parse($log->waktu_update)->format('d M Y, H:i') }}</small>
                                </li>
                                @empty
                                <li class="list-group-item text-center py-4 text-muted small">Belum ada riwayat perubahan.</li>
                                @endforelse
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Kolom Aksi / Update Status -->
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm overflow-hidden sticky-top" style="top: 100px; z-index: 1;">
                        <div class="card-header bg-warning py-3 border-0">
                            <h5 class="mb-0 fw-bold text-dark"><i class="bi bi-pencil-square me-2"></i>Ubah Status</h5>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('admin.kunjungan.status', $kunjungan->id_kunjungan) }}" method="POST">
                                @csrf
                                <div class="mb-3">
                                    <label class="form-label small fw-bold">Status Kunjungan</label>
                                    <select name="status_kunjungan" class="form-select border-warning-subtle py-2" required>
                                        <option value="pending" {{ $kunjungan->status_kunjungan === 'pending' ? 'selected' : '' }}>🕒 Pending (Menunggu)</option>
                                        <option value="diterima" {{ $kunjungan->status_kunjungan === 'diterima' ? 'selected' : '' }}>✅ Terima Kunjungan</option>
                                        <option value="ditolak" {{ $kunjungan->status_kunjungan === 'ditolak' ? 'selected' : '' }}>❌ Tolak Kunjungan</option>
                                    </select>
                                </div>
                                <div class="mb-4">
                                    <label class="form-label small fw-bold">Catatan / Keterangan Tambahan</label>
                                    <textarea name="keterangan" class="form-control border-warning-subtle" rows="4" placeholder="Tulis alasan jika ditolak atau catatan tambahan...">{{ $kunjungan->keterangan }}</textarea>
                                </div>
                                <button type="submit" class="btn btn-warning w-100 fw-bold py-2 shadow-sm">
                                    Simpan Perubahan
                                </button>
                            </form>
                        </div>
                        <div class="card-footer bg-light border-0 py-3 text-center">
                            <small class="text-muted">Status saat ini: 
                                <span class="fw-bold text-uppercase">{{ $kunjungan->status_kunjungan }}</span>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>