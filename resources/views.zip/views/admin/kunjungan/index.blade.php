<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Kunjungan - Admin KSOP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <style>
        body { overflow-x: hidden; background-color: #f8f9fa; }
        #sidebar {
            min-width: 250px; max-width: 250px;
            min-height: 100vh; background-color: #dc3545;
            transition: all 0.3s; position: fixed;
        }
        #sidebar .sidebar-header { padding: 20px; background: #b02a37; }
        #sidebar ul.components { padding: 20px 0; }
        #sidebar ul li a { padding: 10px 20px; display: block; color: white; text-decoration: none; }
        #sidebar ul li a:hover { background: #b02a37; }
        #sidebar ul li.active > a { background: #a02632; font-weight: bold; }
        #content { width: calc(100% - 250px); margin-left: 250px; min-height: 100vh; }
        .navbar-custom { background-color: white; box-shadow: 0 2px 4px rgba(0,0,0,.08); }
        .card { border: none; border-radius: 10px; }
        @media (max-width: 768px) {
            #sidebar { margin-left: -250px; }
            #content { width: 100%; margin-left: 0; }
        }
    </style>
</head>
<body>

<div class="d-flex">
    <!-- Sidebar -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <h4 class="text-white mb-0">Admin KSOP</h4>
        </div>
        <ul class="list-unstyled components">
            <li><a href="{{ route('admin.dashboard') }}"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a></li>
            <li><a href="{{ route('admin.tamu.index') }}"><i class="bi bi-people-fill me-2"></i> Data Tamu</a></li>
            <li class="active"><a href="#"><i class="bi bi-calendar-check me-2"></i> Data Kunjungan</a></li>
            <li><a href="#"><i class="bi bi-journal-text me-2"></i> Laporan</a></li>
            <hr class="text-white">
            <li><a href="#"><i class="bi bi-box-arrow-right me-2"></i> Keluar</a></li>
        </ul>
    </nav>

    <!-- Page Content -->
    <div id="content">
        <!-- Top Navbar -->
        <nav class="navbar navbar-expand-lg navbar-custom px-4 py-3">
            <div class="container-fluid">
                <span class="navbar-brand mb-0 h1">Data Kunjungan</span>
                <div class="d-flex align-items-center text-muted">
                    <i class="bi bi-person-circle me-2"></i>
                    <span>Admin</span>
                </div>
            </div>
        </nav>

        <div class="container-fluid p-4">
            
            @if(session('success'))
                <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm mb-4">
                    <i class="bi bi-check-circle-fill me-2"></i> {{ session('success') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif

            <!-- Filter & Action Card -->
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3 align-items-center">
                        <div class="col-auto">
                            <label class="text-muted small d-block">Filter Status:</label>
                            <select name="status" class="form-select border-secondary-subtle">
                                <option value="">Semua Status</option>
                                <option value="pending" {{ request('status') === 'pending' ? 'selected' : '' }}>🕒 Pending</option>
                                <option value="diterima" {{ request('status') === 'diterima' ? 'selected' : '' }}>✅ Diterima</option>
                                <option value="ditolak" {{ request('status') === 'ditolak' ? 'selected' : '' }}>❌ Ditolak</option>
                            </select>
                        </div>
                        <div class="col-auto align-self-end">
                            <button class="btn btn-danger px-4">
                                <i class="bi bi-filter"></i> Terapkan
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Table Card -->
            <div class="card shadow-sm">
                <div class="card-header bg-white py-3">
                    <h5 class="mb-0 text-dark fw-bold">Daftar Kunjungan Hari Ini</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="px-4 py-3">No. Antrian</th>
                                    <th>Tamu</th>
                                    <th>Tanggal</th>
                                    <th>Bidang</th>
                                    <th>Status</th>
                                    <th class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($kunjungans as $k)
                                @php $s = $k->status_kunjungan; @endphp
                                <tr>
                                    <td class="px-4 fw-bold text-danger">#{{ $k->nomor_antrian }}</td>
                                    <td>
                                        <div class="d-flex flex-column">
                                            <span>{{ $k->tamu->nama ?? '-' }}</span>
                                            <small class="text-muted" style="font-size: 0.75rem;">{{ $k->tamu->instansi ?? '-' }}</small>
                                        </div>
                                    </td>
                                    <td>{{ \Carbon\Carbon::parse($k->tanggal_kunjungan)->format('d M Y') }}</td>
                                    <td><span class="badge bg-secondary-subtle text-secondary border">{{ $k->bidang->nama_bidang ?? '-' }}</span></td>
                                    <td>
                                        @if($s === 'diterima')
                                            <span class="badge rounded-pill bg-success-subtle text-success px-3 border border-success">Diterima</span>
                                        @elseif($s === 'ditolak')
                                            <span class="badge rounded-pill bg-danger-subtle text-danger px-3 border border-danger">Ditolak</span>
                                        @else
                                            <span class="badge rounded-pill bg-warning-subtle text-warning px-3 border border-warning">Pending</span>
                                        @endif
                                    </td>
                                    <td class="text-center px-4">
                                        <div class="d-flex gap-2 justify-content-center">
                                            <a href="{{ route('admin.kunjungan.detail', $k->id_kunjungan) }}"
                                                class="btn btn-sm btn-light border" title="Lihat Detail">
                                                <i class="bi bi-eye text-primary"></i>
                                            </a>
                                            <form action="{{ route('admin.kunjungan.hapus', $k->id_kunjungan) }}" method="POST"
                                                onsubmit="return confirm('Hapus data kunjungan ini?')">
                                                @csrf @method('DELETE')
                                                <button class="btn btn-sm btn-light border" title="Hapus">
                                                    <i class="bi bi-trash text-danger"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="6" class="text-center py-5 text-muted">
                                        <i class="bi bi-calendar-x fs-1 d-block mb-2"></i>
                                        Tidak ada data kunjungan ditemukan.
                                    </td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>